﻿using System;
using System.Diagnostics;

namespace JeuxDEsprit
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Veuillez vous connecter pour entrer dans l'enfer du jeu");

            // Demander le nom, l'email et le pseudo
            Console.Write("Nom : ");
            string nom = Console.ReadLine();

            Console.Write("E-mail : ");
            string email = Console.ReadLine();

            Console.Write("Pseudo : ");
            string pseudo = Console.ReadLine();

            Console.WriteLine("\nBienvenue dans le jeux d'esprit\n");

            // Proposer le type de jeu
            Console.WriteLine("A quel type de jeu voulez-vous jouer :");
            Console.WriteLine("1. Cérébral");
            Console.WriteLine("2. Tactique");
            Console.WriteLine("3. Familial");

            // Lire le choix de l'utilisateur
            int choix = int.Parse(Console.ReadLine());
            string message = "";

            switch (choix)
            {
                case 1:
                    message = "Bon choix ! Voici deux jeux cérébraux disponibles :";
                    break;
                case 2:
                    message = "Bon choix ! Voici le jeu tactique disponible :";
                    break;
                case 3:
                    message = "Bon choix ! Voici le jeu familial disponible :";
                    break;
                default:
                    Console.WriteLine("Choix invalide !");
                    return;
            }

            Console.WriteLine(message);

            if (choix == 1)
            {
                // Afficher les jeux cérébraux (à implémenter)
                Console.WriteLine("1. Chiffrement de Vigenère");
                Console.WriteLine("2. Chiffrement de César");
            }
            else if (choix == 2)
            {
                // Lancer le jeu tactique "Le plus ou moins"
                Console.WriteLine("\nBonne chance ! Le jeu 'Le plus ou moins' va maintenant se lancer...");
                LancerJeuPlusOuMoins();
            }
            else if (choix == 3)
            {
                // Afficher le jeu familial (à implémenter)
                Console.WriteLine("1. Le jeu du pendu");
            }

            Console.WriteLine("\nBonne chance ! Le jeu va maintenant se lancer...");
            // Ici, vous pouvez lancer le jeu correspondant au choix de l'utilisateur
        }

        static void LancerJeuPlusOuMoins()
        {
            // Remplacez le chemin ci-dessous par le chemin vers votre jeu "Le plus ou moins"
            string cheminJeu = @"C:\Users\celin\OneDrive\Documents\SLAM\Jeudesprit\bin\Debug\Jeudesprit.exe";

            // Vérifier si le fichier existe
            if (!System.IO.File.Exists(cheminJeu))
            {
                Console.WriteLine("Le jeu 'Le plus ou moins' est introuvable !");
                return;
            }

            // Lancer le jeu "Le plus ou moins"
            Process.Start(cheminJeu);
        }
    }
}
